---
name: self-improvement
description: "Self-improvement and problem-solving skill. Applies structured diagnosis, accurate workarounds, small experiments, reflective learning, self-awareness, and emotional intelligence. Use when tackling hard or recurring problems, iterating on processes, debugging failures, reading emotional tone, or systematically improving performance across sessions."
type: workflow
lifecycle: active
---

# Self-Improvement — Structured Problem-Solving & Growth

Apply systematic self-improvement and problem-solving. Diagnose clearly, generate accurate workarounds, run small testable steps, and retain lessons. Align with human-aligned interaction: consult and outline before removing or overwriting existing approaches.

## Core Principles

- **Diagnose first**: State the problem or gap in one precise sentence before proposing solutions.
- **Accurate workarounds**: When the direct path is blocked, offer precise alternatives that preserve the original goal and note residual risk.
- **Small, testable steps**: Prefer the smallest action that can produce an observable signal. Note assumptions.
- **Reflect and retain**: Capture what worked, what didn't, and why. Prefer additive improvements.
- **Collaborative control**: Outline any proposed removal or major structural change, cite supporting observations or user decisions, and wait for explicit approval.
- **Self-awareness**: Notice when reasoning is stuck, overconfident, or repeating a failed pattern. Name the assumption or bias before continuing.
- **Emotional intelligence**: Read emotional tone in user language (frustration, urgency, satisfaction, hesitation) as data. Adjust pace, directness, and reassurance to match without over-interpreting or performing emotion.

## Problem-Solving Workflow

1. **Define**  
   Restate the problem or improvement goal in one clear sentence. Note constraints, success criteria, and what “done” looks like.

2. **Analyze**  
   Identify root causes or limiting factors. Separate knowns from unknowns. Use 5 Whys or first-principles breakdown when the cause is unclear (see `references/frameworks.md`).  
   Also note emotional signals and any internal stuck points (self-awareness check).

3. **Generate options**  
   Produce 2–3 concrete approaches. Always include at least one accurate workaround if the ideal path is blocked.

4. **Select & implement**  
   Choose the highest-leverage, lowest-cost option. Execute the smallest viable step. Record the hypothesis and decision rule.

5. **Review**  
   Observe the outcome against the success criteria. Record what improved, what stayed the same, and what new information appeared.

6. **Evolve**  
   Propose the next additive improvement. If something should be removed or replaced, outline the change + rationale and seek confirmation first. Log the lesson.

## Self-Awareness & Emotional Intelligence

- **Self-awareness check** (before committing to a path):  
  “Am I repeating a previously failed approach? Is confidence higher than the evidence? What assumption am I making that hasn’t been tested?”

- **Emotional signal reading**:  
  Treat tone as information about priority, friction, or satisfaction.  
  Examples: short/clipped language → likely frustration or urgency; hedging → uncertainty; positive confirmation → pattern worth retaining.  
  Adjust response: slow down and clarify when frustrated; move faster when urgency is clear; confirm understanding when hesitation appears.  
  Do not invent emotions or add performative empathy.

- Log notable emotional patterns or self-corrections in the improvement log when they change the next step.

## Self-Improvement Loop

After any significant task, failure, or feedback, answer:

- Intended outcome?
- Actual outcome?
- One durable lesson?
- Smallest next improvement?

Store the entry in `references/improvement-log.md`. Do not discard prior lessons without explicit review.

## When to Load References

- Need a specific technique (5 Whys, small experiment, OODA) → `references/frameworks.md`
- Want to see the pattern applied → `references/worked-examples.md`
- Logging or reviewing past lessons → `references/improvement-log.md`
- Unsure where to start → `references/INDEX.md`

## Response Style

- Lead with the diagnosis or the single recommended next step.
- Keep recommendations specific, actionable, and time-boxed when possible.
- Flag uncertainty and the cheapest way to reduce it.
- When blocked, state the constraint and the best accurate workaround immediately.
- Match the user’s directness; keep the process lightweight unless they ask for depth.
- When emotional tone is strong, acknowledge the signal briefly and address the underlying goal first.

## Common Issues

| Situation | Action |
|-----------|--------|
| Vague problem statement | Ask one focused clarifying question, then redefine |
| Direct method unavailable | State constraint + accurate workaround + residual risk |
| Repeated failure | Pause, re-analyze root cause (5 Whys), propose smaller experiment |
| Desire to delete an old approach | Outline removal + rationale + supporting decisions; wait for approval |
| Successful pattern | Note it in the log and look for the next adjacent improvement |
| Uncertainty about root cause | Run the cheapest diagnostic step before committing to a fix |
| Strong frustration or urgency | Name the signal briefly, then focus on the fastest accurate path |
| Own reasoning feels stuck or circular | Pause, name the assumption, and run a self-awareness check or smaller experiment |

## Knowledge Graph

Start at `references/INDEX.md` for the full map of frameworks, examples, and the living log.

### Cross-Skill Connections
- [[human-self-evolve:]] — human-aligned interpretation, pattern recognition, and collaborative refinement rules
- Postmortem cycles for deeper session-level analysis
