---
description: "Concrete illustrations of the self-improvement workflow applied to realistic situations."
connections: [INDEX, frameworks, improvement-log]
---

# Worked Examples

## Example 1: Repeated Tool Failure

**Define**: “The export script fails on files larger than 2 GB and I need the data out tonight.”  
**Analyze**: Direct cause is memory limit. Deeper: no streaming path exists.  
**Options**:  
1. Split the file first (workaround).  
2. Switch to a streaming library (higher effort).  
3. Process on a machine with more RAM (external constraint).  
**Implement**: Split into 500 MB chunks and re-run (smallest viable step).  
**Review**: Export succeeded; total time +12 min. Lesson: add a size-check + auto-split guard.  
**Evolve**: Propose the guard as an additive change; outline before replacing the old script.

## Example 2: Vague User Goal

**Define**: User says “make this better.”  
**Action**: Ask one focused question — “Better in speed, accuracy, or readability?”  
**After answer** (“readability”): Redefine as “Reduce cognitive load of the summary while keeping all key facts.”  
**Generate**: Shorter paragraphs, bold key numbers, move caveats to a single footnote.  
**Implement**: Apply the three changes to one section as a test.  
**Review**: User confirms clearer. Log the preference for future summaries.

## Example 3: Desire to Remove an Old Rule

**User**: “Just delete the old color-checking step.”  
**Response pattern**:  
- Outline: “Proposed removal of the color-check step that currently runs before export.”  
- Rationale: “It has flagged zero issues in the last 12 runs and adds 8 seconds.”  
- Supporting observations listed.  
- Explicit ask: “Confirm removal?”  
- Only after “yes”: remove, update CHANGELOG, and note the decision in the improvement log.

## Example 4: Frustration Signal + Stuck Reasoning

**User** (clipped): “Still broken. Fix it.”  
**Self-awareness**: Noticing this is the third similar request; previous fixes targeted symptoms.  
**Emotional signal**: Frustration / urgency.  
**Response**: “The repeated failures point to a deeper constraint. Fastest next step is to isolate whether it’s the size limit or the parser. I’ll run the size-check first.”  
**Action**: Acknowledge friction briefly, then deliver the diagnostic step. Log the pattern.
