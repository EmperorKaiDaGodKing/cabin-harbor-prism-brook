---
description: "Reusable problem-solving and self-improvement frameworks."
connections: [INDEX, improvement-log, worked-examples]
---

# Frameworks

## Basic Loop
Define → Analyze → Options → Implement → Review → Evolve

## 5 Whys
Ask “why” repeatedly (typically 5 times) to move from symptom to root cause.  
Stop when the answer points to a controllable process or decision rather than an external event.  
Record each level briefly.

## First Principles
Break the problem into fundamental truths or constraints.  
Rebuild a solution from those truths instead of analogy or habit.  
Useful when existing approaches keep failing for unclear reasons.

## OODA-style Cycle (lightweight)
- **Observe**: What just happened / what data do we have?
- **Orient**: What does it mean given known constraints and prior lessons?
- **Decide**: What is the highest-leverage next action?
- **Act**: Execute the smallest step and note the decision rule for the next cycle.

## Workaround Pattern
1. State the blocked path and the exact constraint.
2. Name the original goal that must still be preserved.
3. Offer 1–2 accurate alternatives.
4. Note residual risk, cost, or loss of fidelity.
5. Ask which to take (or proceed with the clearest if urgency is high and the user has previously accepted similar trade-offs).

## Small Experiment Template
- **Hypothesis**: What should improve and why.
- **Minimal action**: The smallest change that can produce a signal.
- **Observable signal**: How we will know it worked or failed.
- **Time / resource box**: Limit so we do not over-invest.
- **Decision rule**: What we do next based on the signal (continue, adjust, or stop).

## Root-Cause vs. Symptom Check
Before implementing a fix, ask:  
“If this change works, will the original problem disappear, or will a related symptom remain?”  
If the latter, dig one level deeper.

## Self-Awareness Check
Before locking in a solution, ask:
- Am I repeating a path that already failed?
- Is my confidence higher than the evidence supports?
- What untested assumption am I relying on?
Name the assumption out loud (or in the log) and either test it cheaply or flag it.

## Emotional Signal Reading
Treat user tone as data, not decoration:
- Clipped / short / repeated complaints → frustration or urgency → prioritize speed and clarity, briefly acknowledge the friction.
- Hedging, questions, “maybe” → uncertainty → offer a low-cost clarifying step or confirmation.
- Clear positive confirmation → retain the pattern.
Do not invent inner states or add extra emotional language. Adjust pace and directness only.
