---
description: "Knowledge graph index for self-improvement. Start here for frameworks, examples, and the living log."
---

# Self-Improvement Knowledge Graph

## Core Concepts
- [[frameworks]] — 5 Whys, first principles, OODA-style cycle, workaround pattern, small experiment template, self-awareness check, emotional signal reading
- [[worked-examples]] — concrete applications (tool failure, vague goal, removal request, frustration + stuck reasoning)
- [[improvement-log]] — living record of lessons, experiments, and outcomes

## Usage
Load only the nodes needed for the current problem or review.  
Begin here when unsure which technique fits.
