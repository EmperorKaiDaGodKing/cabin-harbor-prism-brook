# Changelog

## 2026-10-11
- Initial skill creation
- Defined structured problem-solving workflow and self-improvement loop
- Emphasized accurate workarounds and collaborative control over removals

## 2026-10-11 (expansion)
- Expanded frameworks with 5 Whys, first principles, OODA-style cycle, and small-experiment template
- Added worked-examples.md with three concrete illustrations
- Tightened SKILL.md guidance (when to load references, root-cause check, response style)
- Updated INDEX and improvement log
- Added evals and triggers for better coverage

## 2026-10-11 (self-awareness + EI)
- Added self-awareness and emotional intelligence principles
- Integrated self-awareness check and emotional signal reading into workflow and frameworks
- Added worked example for frustration + stuck reasoning
- Updated common issues, response style, description, INDEX, and evals/triggers

