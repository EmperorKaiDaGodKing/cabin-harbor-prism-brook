---
description: "Knowledge graph index for human-self-evolve. Start here for pattern logs and evolution history."
---

# Human Self-Evolve Knowledge Graph

## Core Concepts
- [[evolution-log]] — session lessons, recognized patterns, and proposed refinements
- [[human-principles]] — guidelines for interpreting user input as human rather than computational

## Usage
Read relevant nodes only when refining or learning from a session.
